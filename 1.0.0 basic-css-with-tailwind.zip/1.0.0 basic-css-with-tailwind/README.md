# Next.js + Tailwind CSS Example

This example shows how to use [Tailwind CSS](https://tailwindcss.com/) (v2) with Next.js. It follows the steps outlined in the official [Tailwind docs](https://tailwindcss.com/docs/guides/nextjs).

## Deploy your own

Deploy the example using [Vercel](https://vercel.com?utm_source=github&utm_medium=readme&utm_campaign=next-example):

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/git/external?repository-url=https://github.com/vercel/next.js/tree/canary/examples/with-tailwindcss&project-name=with-tailwindcss&repository-name=with-tailwindcss)

## How to use

Execute [`create-next-app`](https://github.com/vercel/next.js/tree/canary/packages/create-next-app) with [npm](https://docs.npmjs.com/cli/init) or [Yarn](https://yarnpkg.com/lang/en/docs/cli/create/) to bootstrap the example:

```bash
npx create-next-app --example with-tailwindcss with-tailwindcss-app
# or
yarn create next-app --example with-tailwindcss with-tailwindcss-app
```

Deploy it to the cloud with [Vercel](https://vercel.com/new?utm_source=github&utm_medium=readme&utm_campaign=next-example) ([Documentation](https://nextjs.org/docs/deployment)).

https://www.youtube.com/watch?v=3u_vIdnJYLc

- [x] put your color in root
- [x] standar typing css className and scoping
https://css-tricks.com/bem-101/
- [x] no important in style because important style milik bootstrap / tailwind
- [x] 100vw vh, calc 


- [x] flex
- [x] position: relative, absolute, fixed
- [x] grid


1. install node js 14.5

2. install boiler plate next js with tailwin
  https://github.com/vercel/next.js/tree/canary/examples/with-tailwindcss

3. install react versi 1latest (17.0.1)
   npm i react / yarn add react
 becarse next minta react yang terbaru

4. pindahin folder (optional) bisa langsung ke step 5 hanya untuk expert, boleh di coba kalau belum
 - page ke src
 - style ke public

5. install sass biar bisa nested
   npm i sass / yarn add sass

5 next js itu auto routing jadi bkin folder aja trus route

https://developer.mozilla.org/en-US/docs/Web/CSS/flex
https://flexboxfroggy.com/


6. base url, ngilangin ../.. dah
https://nextjs.org/docs/advanced-features/module-path-aliases


author : https://www.linkedin.com/in/helmi-fauzi-12b872143/