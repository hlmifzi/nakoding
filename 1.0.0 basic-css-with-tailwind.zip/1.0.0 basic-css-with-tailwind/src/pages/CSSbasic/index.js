import Head from 'next/head'
import Announcement from '@/components/announcement/Announcement'
import Navbar from '@/components/navbar/Navbar'
import Widget from '@/components/widget/Widget'

export default function Home() {
  return (
    <div>
      <Head>
        <title>Create Next App</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <main>
        <Announcement />
        <Navbar />
        <Widget />
      </main>
    </div>
  )
}
