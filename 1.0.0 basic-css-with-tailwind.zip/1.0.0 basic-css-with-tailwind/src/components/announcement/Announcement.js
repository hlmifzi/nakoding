
const Announcement = () => {
  return (
    <div className="announcement">
      <p>Dicari Ukhti siap nikah untuk  kawan kita .... (isi sendiri) !</p>
      <div className="announcement_icon">x</div>
    </div>
  )
}

export default Announcement
