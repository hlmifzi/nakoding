const Navbar = () => {
  return (
    <div className="navbar">
      <div className="navbar_logo">
        <img
          src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/Facebook_f_logo_%282019%29.svg/1200px-Facebook_f_logo_%282019%29.svg.png"
          alt=""
        />
      </div>

      <div className="navbar_menu">
        <span className="navbar_menuOption">menu 1</span>
        <span className="navbar_menuOption">menu 2</span>
        <span className="navbar_menuOption">menu 3</span>
      </div>

      <div className="navbar_account">
        <img
          src="https://image.shutterstock.com/image-vector/shopping-cart-icon-metro-user-600w-568084216.jpg"
          alt=""
        />
        <span>5</span>
      </div>
    </div>
  )
}

export default Navbar
