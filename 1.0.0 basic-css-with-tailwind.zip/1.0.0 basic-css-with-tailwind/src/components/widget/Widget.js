const Widget = () => {
  return (
    <div className="widget">
      <div className="widget_container">
        <div className="widget_item">2</div>
        <div className="widget_item">3</div>
        <div className="widget_item">4</div>
        <div className="widget_item">5</div>
        <div className="widget_item">1</div>
      </div>
    </div>
  )
}

export default Widget
